module.exports=[38783,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactServerDOMTurbopackClient}];

//# sourceMappingURL=546c1_route-modules_app-page_vendored_ssr_react-server-dom-turbopack-client_02bbd93e.js.map