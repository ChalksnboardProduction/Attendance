(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__af6e68da._.css",
  "static/chunks/node_modules_202cea27._.js",
  "static/chunks/_73794214._.js"
],
    source: "dynamic"
});
